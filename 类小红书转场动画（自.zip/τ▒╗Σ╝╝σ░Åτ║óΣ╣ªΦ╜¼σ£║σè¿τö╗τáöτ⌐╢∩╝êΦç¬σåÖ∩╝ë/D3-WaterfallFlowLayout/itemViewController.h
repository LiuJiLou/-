//
//  itemViewController.h
//  D3-WaterfallFlowLayout
//
//  Created by 刘吉楼 on 16/7/19.
//  Copyright © 2016年 qianfeng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface itemViewController : UIViewController

@property(nonatomic,strong) UIImageView * imageView;
@property(nonatomic,strong) UIImage * image;

@end
