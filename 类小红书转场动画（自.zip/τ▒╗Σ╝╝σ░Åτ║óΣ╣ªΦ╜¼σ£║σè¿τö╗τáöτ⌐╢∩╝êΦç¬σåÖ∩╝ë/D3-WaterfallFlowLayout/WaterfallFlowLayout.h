//
//  WaterfallFlowLayout.h
//  D3-WaterfallFlowLayout
//
//  Created by qianfeng on 15/12/23.
//  Copyright © 2015年 qianfeng. All rights reserved.
//

#import <UIKit/UIKit.h>
// 类的前置声明
@class WaterfallFlowLayout;

@protocol WaterfallFlowLayoutDelegate <NSObject>
// 动态获取 item 宽度
- (CGFloat) WaterfallFlowLayout:(WaterfallFlowLayout *) layout widthForItemAtIndexPath:(NSIndexPath *) indexPath;

@end

@interface WaterfallFlowLayout : UICollectionViewLayout

@property (nonatomic,assign) id <WaterfallFlowLayoutDelegate> delegate;

@property (nonatomic) NSInteger numberOfColumns;
@property (nonatomic) CGFloat minimumLineSpacing;
@property (nonatomic) CGFloat minimumInteritemSpacing;
@property (nonatomic) UIEdgeInsets sectionInset;
@end
