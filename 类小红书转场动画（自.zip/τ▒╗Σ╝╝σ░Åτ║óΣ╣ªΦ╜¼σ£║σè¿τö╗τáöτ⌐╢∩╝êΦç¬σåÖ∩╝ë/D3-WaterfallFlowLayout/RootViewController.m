//
//  RootViewController.m
//  D3-WaterfallFlowLayout
//
//  Created by qianfeng on 15/12/23.
//  Copyright © 2015年 qianfeng. All rights reserved.
//

#import "RootViewController.h"
#import "WaterfallFlowLayout.h"
#import "ASFSharedViewTransition.h"
#import "itemViewController.h"

@interface RootViewController () <UICollectionViewDataSource,UICollectionViewDelegateFlowLayout,WaterfallFlowLayoutDelegate,ASFSharedViewTransitionDataSource>
{
    UICollectionView * _collectionView;
}
@property (nonatomic, retain) NSMutableArray *arrImages;
@end

@implementation RootViewController
- (void)dealloc {
    [_collectionView release];
    [super dealloc];
    
}

- (void)viewDidLoad {
    [super viewDidLoad];
    _arrImages = [[NSMutableArray alloc] init];
    for (int i=1; i<=102; i++) {
        int j=0;
        if ((i%9)==0) {
            j=1;
        }else{
            j=i%9;
        }
        [_arrImages addObject:[UIImage imageNamed:[NSString stringWithFormat:@"nature%d.jpg", j]]];
    }

    // 创建集合视图
    [self createCollectionView];
}

-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    if ([segue.destinationViewController isKindOfClass:[itemViewController class]]) {
        // Get the selected item index path
        NSIndexPath *selectedIndexPath = [[_collectionView indexPathsForSelectedItems] firstObject];
        
        // Set the thing on the view controller we're about to show
        if (selectedIndexPath != nil) {
            itemViewController *detailVC = segue.destinationViewController;
            detailVC.image = self.arrImages[selectedIndexPath.item];
        }
    }
}

#pragma mark - ASFSharedViewTransitionDataSource
-(UIView *)sharedView
{
     return [_collectionView cellForItemAtIndexPath:[[_collectionView indexPathsForSelectedItems] firstObject]];
}

- (UICollectionViewLayout *)createLayout {
#if 1
    WaterfallFlowLayout * layout = [[WaterfallFlowLayout alloc] init];
    layout.sectionInset = UIEdgeInsetsMake(20, 20, 20, 20);
    layout.minimumLineSpacing = 10;
    layout.minimumInteritemSpacing = 20;
    layout.numberOfColumns = 3;
    layout.delegate = self;
    [self performSelector:@selector(changeLayout:) withObject:layout afterDelay:3];

#else
    UICollectionViewFlowLayout * layout = [[UICollectionViewFlowLayout alloc] init];
    
    layout.minimumLineSpacing = 10;
    layout.itemSize = CGSizeMake(150, 100);
    layout.sectionInset = UIEdgeInsetsMake(10, 10, 10, 10);
    
#endif
    
    
    return [layout autorelease];
}
- (void)changeLayout:(WaterfallFlowLayout *)layout {
    layout.numberOfColumns = 3;
}


- (void)createCollectionView {
    CGRect frame = CGRectMake(0, 20, VIEW_WIDTH, VIEW_HEIGHT-20);
    _collectionView = [[UICollectionView alloc] initWithFrame:frame collectionViewLayout:[self createLayout]];

    _collectionView.backgroundColor = [UIColor cyanColor];
    // 设置代理
    _collectionView.delegate = self;
    _collectionView.dataSource = self;
    
    // 注册cell 类型 及 复用标识
    [_collectionView registerClass:[UICollectionViewCell class] forCellWithReuseIdentifier:@"cellId"];
    
    
    [self.view addSubview:_collectionView];
}

#pragma mark - UICollectionViewDataSource

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
//    return 102;
    return _arrImages.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
//    UICollectionViewCell * cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"cellId" forIndexPath:indexPath];
    
//    UILabel * label = nil;
//    NSArray * array = cell.contentView.subviews;
//    if (array.count) {
//        label = array[0];
//    }else {
//        label = [[UILabel alloc] init];
////        label.frame = cell.bounds;
//        label.textAlignment = NSTextAlignmentCenter;
//        label.font = [UIFont systemFontOfSize:50];
//        [cell.contentView addSubview:label];
//        [label release];
//    }
//    label.frame = cell.bounds;
//    label.text = [NSString stringWithFormat:@"%ld",(long)indexPath.item];
//    label.textColor = [UIColor whiteColor];
//    cell.backgroundColor = RandomColor;
    
//    return cell;
    
//    static NSString * cellId = @"cellId";
//    UICollectionViewCell * cell = [collectionView dequeueReusableCellWithReuseIdentifier:cellId forIndexPath:indexPath];
    UICollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"cellId" forIndexPath:indexPath];
    
    cell.backgroundColor = [UIColor whiteColor];
    
    UIImageView * imageView = [[UIImageView alloc] init];
    imageView.frame = cell.bounds;
    
    if (_arrImages.count > indexPath.item) {
        UIImage * image = [_arrImages objectAtIndex:indexPath.item];
        [imageView setImage:image];
        
        UIImage *img = self.arrImages[indexPath.row];
        
        cell.layer.contents = (id)img.CGImage;

    }

        //移除cell
    for (id subView in cell.contentView.subviews) {
        [subView removeFromSuperview];
    }
    
    [cell.contentView addSubview:imageView];
    return cell;

}

- (CGSize) collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath {
//    return CGSizeMake( arc4random()%100+200, 110);
    return CGSizeMake( 80, 110);
}

//-(CGFloat) WaterfallFlowLayout:(WaterfallFlowLayout *)layout widthForItemAtIndexPath:(NSIndexPath *)indexPath{
//    return arc4random()%150+50;
//}

-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    NSLog(@"点击了第 %ld 组，第 %ld 行",(long)indexPath.section,(long)indexPath.row);
    itemViewController * itemVC = [[itemViewController alloc] init];
    if (_arrImages.count > indexPath.item) {
        itemVC.image = [_arrImages objectAtIndex:indexPath.item];
    }
    [self.navigationController pushViewController:itemVC animated:YES];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}


@end
