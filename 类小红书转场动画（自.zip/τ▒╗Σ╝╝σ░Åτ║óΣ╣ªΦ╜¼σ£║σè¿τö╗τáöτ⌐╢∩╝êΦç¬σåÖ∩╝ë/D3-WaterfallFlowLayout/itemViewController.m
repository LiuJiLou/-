//
//  itemViewController.m
//  D3-WaterfallFlowLayout
//
//  Created by 刘吉楼 on 16/7/19.
//  Copyright © 2016年 qianfeng. All rights reserved.
//

#import "itemViewController.h"
#import "utility.pch"
#import "ASFSharedViewTransition.h"

@interface itemViewController ()<ASFSharedViewTransitionDataSource>

@end

@implementation itemViewController

-(void)loadView
{
    [super loadView];
    
    _imageView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, VIEW_WIDTH, VIEW_WIDTH)];
    [self.view addSubview:_imageView];
    UILabel * label = [[UILabel alloc] initWithFrame:CGRectMake(0, VIEW_WIDTH+10, VIEW_WIDTH, VIEW_HEIGHT-VIEW_WIDTH-10)];
    label.text = @"11111111111111111wwwwwwwwwwwwwwwwwwwwwwwwwwwwwqqqqqqqqqqqqqqqqqfffffffffffaaaaaaaaaaaaaa";
    label.numberOfLines = 0;
    [self.view addSubview:label];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    _imageView.image = _image;
}

#pragma mark - ASFSharedViewTransitionDataSource
-(UIView *)sharedView
{
    return _imageView;
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
